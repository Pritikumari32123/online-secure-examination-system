import os

# Basic configuration
SECRET_KEY = os.urandom(24).hex()
SQLALCHEMY_DATABASE_URI = 'postgresql://examuser:exam123@localhost/examdb'
SQLALCHEMY_TRACK_MODIFICATIONS = False

# Security settings
SESSION_PROTECTION = 'strong'

# Environment configuration
DEBUG = True