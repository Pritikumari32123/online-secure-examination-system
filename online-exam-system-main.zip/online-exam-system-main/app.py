from flask import Flask, render_template, redirect, url_for, request, flash, abort, jsonify
from functools import wraps

# Role requirement decorator



from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user

# Role requirement decorator
def role_required(role):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated or current_user.role != role:
                flash('Access denied', 'danger')
                return redirect(url_for('index'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField, IntegerField, ValidationError
from werkzeug.security import generate_password_hash, check_password_hash
from wtforms.validators import DataRequired
import datetime

app = Flask(__name__)
app.config.from_object('config')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///exam.db'

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Database models
class StudentGroup(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    students = db.relationship('User', secondary='student_group_membership')
    assigned_exams = db.relationship('Exam', secondary='group_exam_assignment')

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True)
    password = db.Column(db.String(120))
    role = db.Column(db.String(20))
    groups = db.relationship('StudentGroup', secondary='student_group_membership', back_populates='students')

student_group_membership = db.Table('student_group_membership',
    db.Column('user_id', db.Integer, db.ForeignKey('user.id'), primary_key=True),
    db.Column('group_id', db.Integer, db.ForeignKey('student_group.id'), primary_key=True)
)

group_exam_assignment = db.Table('group_exam_assignment',
    db.Column('group_id', db.Integer, db.ForeignKey('student_group.id'), primary_key=True),
    db.Column('exam_id', db.Integer, db.ForeignKey('exam.id'), primary_key=True)
)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))



class Exam(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200))
    description = db.Column(db.Text)
    duration = db.Column(db.Integer)  # in minutes
    teacher_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    created_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    questions = db.relationship('Question', backref='exam', lazy=True)
    assigned_groups = db.relationship('StudentGroup', secondary='group_exam_assignment', back_populates='assigned_exams')

class Question(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    exam_id = db.Column(db.Integer, db.ForeignKey('exam.id'))
    question_text = db.Column(db.Text)
    question_type = db.Column(db.String(20))  # 'mcq' or 'subjective'
    options = db.Column(db.JSON)  # For MCQ questions
    correct_answer = db.Column(db.String(200))

class Submission(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    exam_id = db.Column(db.Integer, db.ForeignKey('exam.id'))
    student_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    answers = db.Column(db.JSON)
    score = db.Column(db.Integer)
    submitted_at = db.Column(db.DateTime, default=datetime.datetime.utcnow)
    exam = db.relationship('Exam', backref='submissions', lazy='joined')
    exam = db.relationship('Exam', backref='submissions', lazy='joined')
    exam = db.relationship('Exam', backref='submissions', lazy='joined')

# Authentication forms
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    role = SelectField('Role', choices=[('teacher', 'Teacher'), ('student', 'Student')], validators=[DataRequired()])
    submit = SubmitField('Register')

@app.route('/')
def index():
    return render_template('index.html')

# Authentication routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and check_password_hash(user.password, form.password.data):
            login_user(user)
            next_page = request.args.get('next')
            if current_user.role == 'teacher':
                return redirect(next_page or url_for('teacher_dashboard'))
            return redirect(next_page or url_for('student_dashboard'))
        flash('Invalid username or password', 'danger')
    return render_template('login.html', form=form)

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        existing_user = User.query.filter_by(username=form.username.data).first()
        if existing_user:
            flash('Username already exists', 'danger')
            return redirect(url_for('register'))
        new_user = User(
            username=form.username.data,
            password=generate_password_hash(form.password.data),
            role=form.role.data
        )
        db.session.add(new_user)
        db.session.commit()
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

# Student routes
@app.route('/student/dashboard')
@login_required
def student_dashboard():
    if current_user.role != 'student':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    available_exams = Exam.query.all()
    submissions = Submission.query.filter_by(student_id=current_user.id).all()
    return render_template('student_dashboard.html',
                         available_exams=available_exams,
                         submissions=submissions)

@app.route('/exam/<int:exam_id>/take')
@login_required
@role_required('student')
def take_exam(exam_id):
    exam = Exam.query.get_or_404(exam_id)
    questions = Question.query.filter_by(exam_id=exam_id).all()
    return render_template('take_exam.html', exam=exam, questions=questions)

@app.route('/exam/<int:exam_id>/submit', methods=['POST'])
@login_required
@role_required('student')
def submit_exam(exam_id):
    exam = Exam.query.get_or_404(exam_id)
    answers = {str(q.id): request.form.get(f'answer_{q.id}') for q in exam.questions}
    
    # Auto-grade MCQs
    total_questions = len(exam.questions)
    attempted_questions = sum(1 for q_id, ans in answers.items() if ans and ans.strip())
    correct = 0
    for q in exam.questions:
        if q.question_type == 'mcq':
            student_answer = answers.get(str(q.id))
            if student_answer and q.correct_answer:
                # Compare the full answer text including the letter prefix
                if student_answer.strip() == q.correct_answer.strip():
                    correct += 1
    
    # Calculate percentage based on correct answers
    mcq_questions = sum(1 for q in exam.questions if q.question_type == 'mcq')
    score = int((correct / mcq_questions) * 100) if mcq_questions > 0 else 0
    
    submission = Submission(
        exam_id=exam_id,
        student_id=current_user.id,
        answers=answers,
        score=score
    )
    db.session.add(submission)
    db.session.commit()
    
    flash(f'Exam submitted! Total questions: {total_questions}, Attempted: {attempted_questions}, Correct MCQ answers: {correct}/{mcq_questions} ({score}%)', 'success')
    return redirect(url_for('student_dashboard'))

@app.route('/exam/<int:exam_id>/submissions')
@login_required
@role_required('teacher')
def view_submissions(exam_id):
    exam = Exam.query.get_or_404(exam_id)
    
    # Ensure the teacher owns this exam
    if exam.teacher_id != current_user.id:
        abort(403)
    
    submissions = Submission.query.filter_by(exam_id=exam_id)\
        .join(User, Submission.student_id == User.id)\
        .add_columns(User.username)\
        .all()
    
    # Convert submissions to a list of dictionaries with student info
    submission_list = []
    for sub, username in submissions:
        sub_dict = {
            'id': sub.id,
            'student': {'username': username},
            'submitted_at': sub.submitted_at,
            'score': sub.score,
            'answers': sub.answers
        }
        submission_list.append(sub_dict)
    
    return render_template('view_submissions.html', 
                          exam=exam,
                          submissions=submission_list)

# Student Group Management Routes
@app.route('/teacher/groups')
@login_required
@role_required('teacher')
def manage_groups():
    groups = StudentGroup.query.all()
    students = User.query.filter_by(role='student').all()
    return render_template('manage_groups.html', groups=groups, students=students)

@app.route('/teacher/group/create', methods=['POST'])
@login_required
@role_required('teacher')
def create_group():
    name = request.form.get('name')
    description = request.form.get('description')
    student_ids = request.form.getlist('students[]')
    
    if not name:
        flash('Group name is required', 'danger')
        return redirect(url_for('manage_groups'))
    
    group = StudentGroup(name=name, description=description)
    if student_ids:
        students = User.query.filter(User.id.in_(student_ids)).all()
        group.students.extend(students)
    
    db.session.add(group)
    db.session.commit()
    flash('Group created successfully', 'success')
    return redirect(url_for('manage_groups'))

@app.route('/teacher/group/<int:group_id>/edit', methods=['POST'])
@login_required
@role_required('teacher')
def edit_group(group_id):
    group = StudentGroup.query.get_or_404(group_id)
    name = request.form.get('name')
    description = request.form.get('description')
    student_ids = request.form.getlist('students[]')
    
    if not name:
        flash('Group name is required', 'danger')
        return redirect(url_for('manage_groups'))
    
    group.name = name
    group.description = description
    group.students = User.query.filter(User.id.in_(student_ids)).all() if student_ids else []
    
    db.session.commit()
    flash('Group updated successfully', 'success')
    return redirect(url_for('manage_groups'))

@app.route('/teacher/group/<int:group_id>/delete', methods=['POST'])
@login_required
@role_required('teacher')
def delete_group(group_id):
    group = StudentGroup.query.get_or_404(group_id)
    db.session.delete(group)
    db.session.commit()
    flash('Group deleted successfully', 'success')
    return redirect(url_for('manage_groups'))

@app.route('/teacher/group/<int:group_id>/assign-exam', methods=['POST'])
@login_required
@role_required('teacher')
def assign_exam_to_group(group_id):
    group = StudentGroup.query.get_or_404(group_id)
    exam_id = request.form.get('exam_id')
    
    if not exam_id:
        flash('Please select an exam', 'danger')
        return redirect(url_for('manage_groups'))
    
    exam = Exam.query.get_or_404(exam_id)
    if exam not in group.assigned_exams:
        group.assigned_exams.append(exam)
        db.session.commit()
        flash(f'Exam {exam.title} assigned to group {group.name}', 'success')
    
    return redirect(url_for('manage_groups'))

# Teacher routes
@app.route('/teacher/dashboard')
@login_required
def teacher_dashboard():
    if current_user.role != 'teacher':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    exams = Exam.query.filter_by(teacher_id=current_user.id).all()
    return render_template('teacher_dashboard.html', exams=exams)

class ExamForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    description = StringField('Description')
    duration = IntegerField('Duration (minutes)', validators=[DataRequired()])
    submit = SubmitField('Update Exam')

@app.route('/exam/<int:exam_id>/edit', methods=['GET', 'POST'])
@login_required
@role_required('teacher')
def edit_exam(exam_id):
    exam = Exam.query.get_or_404(exam_id)
    if exam.teacher_id != current_user.id:
        abort(403)
    
    form = ExamForm(obj=exam)
    
    if form.validate_on_submit():
        form.populate_obj(exam)
        db.session.commit()
        flash('Exam updated successfully', 'success')
        return redirect(url_for('teacher_dashboard'))
    
    questions = Question.query.filter_by(exam_id=exam_id).all()
    student_groups = StudentGroup.query.all()
    option_letters = ['A', 'B', 'C', 'D']
    return render_template('edit_exam.html', 
                         exam=exam, 
                         form=form, 
                         questions=questions, 
                         student_groups=student_groups,
                         options_count=4,
                         option_letters=option_letters)  # Pass option letters directly


@app.route('/exam/<int:exam_id>/delete', methods=['POST'])
@login_required
@role_required('teacher')
def delete_exam(exam_id):
    exam = Exam.query.get_or_404(exam_id)
    if exam.teacher_id != current_user.id:
        abort(403)
    db.session.delete(exam)
    db.session.commit()
    flash('Exam deleted successfully', 'success')
    return redirect(url_for('teacher_dashboard'))


@app.route('/exam/create', methods=['POST'])
@login_required
def create_exam():
    if current_user.role != 'teacher':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    
    new_exam = Exam(
        title=request.form['title'],
        description=request.form['description'],
        duration=request.form['duration'],
        teacher_id=current_user.id
    )
    db.session.add(new_exam)
    db.session.commit()
    flash('Exam created successfully', 'success')
    return redirect(url_for('teacher_dashboard'))





# Add questions routes

@app.route('/exam/question/<int:question_id>/edit', methods=['POST'])
@login_required
@role_required('teacher')
def edit_question(question_id):
    question = Question.query.get_or_404(question_id)
    exam = Exam.query.get_or_404(question.exam_id)
    if exam.teacher_id != current_user.id:
        abort(403)
    
    try:
        question.question_text = request.form['question_text']
        question.question_type = request.form['question_type']
        
        if question.question_type == 'mcq':
            options = request.form.getlist('options[]')
            lettered_options = [f"{chr(65+i)}. {opt.strip()}" for i, opt in enumerate(options) if opt.strip()]
            question.options = lettered_options
            
            correct_answer = request.form.get('correct_answer')
            if correct_answer:
                correct_index = ord(correct_answer) - ord('A')
                if 0 <= correct_index < len(lettered_options):
                    question.correct_answer = lettered_options[correct_index]
        else:
            question.options = None
            question.correct_answer = None
        
        db.session.commit()
        return jsonify({'success': True, 'message': 'Question updated successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/exam/question/<int:question_id>/delete', methods=['POST'])
@login_required
@role_required('teacher')
def delete_question(question_id):
    question = Question.query.get_or_404(question_id)
    exam = Exam.query.get_or_404(question.exam_id)
    if exam.teacher_id != current_user.id:
        abort(403)
    db.session.delete(question)
    db.session.commit()
    flash('Question deleted successfully', 'success')
    return redirect(url_for('edit_exam', exam_id=exam.id))

# Add questions routes
class QuestionForm(FlaskForm):
    question_text = StringField('Question', validators=[DataRequired()])
    question_type = SelectField('Type', choices=[('mcq', 'MCQ'), ('subjective', 'Subjective')], validators=[DataRequired()])
    option_a = StringField('Option A')
    option_b = StringField('Option B')
    option_c = StringField('Option C')
    option_d = StringField('Option D')
    correct_answer = SelectField('Correct Answer', choices=[
        ('', 'Select Answer'),
        ('A', 'Option A'),
        ('B', 'Option B'),
        ('C', 'Option C'),
        ('D', 'Option D')
    ])

    def validate(self, extra_validators=None):
        if not super().validate(extra_validators=extra_validators):
            return False
        
        if self.question_type.data == 'mcq':
            # Validate all options are filled for MCQ
            if not self.option_a.data or not self.option_b.data or not self.option_c.data or not self.option_d.data:
                self.question_type.errors.append('All options are required for MCQ questions')
                return False
            
            # Validate correct answer is selected for MCQ
            if not self.correct_answer.data or self.correct_answer.data == '':
                self.correct_answer.errors.append('Please select the correct answer')
                return False
        
        return True

    submit = SubmitField('Add')

@app.route('/exam/<int:exam_id>/add_questions', methods=['GET', 'POST'])
@login_required
@role_required('teacher')
def add_questions(exam_id):
    exam = Exam.query.get_or_404(exam_id)
    form = QuestionForm()
    
    if request.method == 'POST':
        try:
            questions_data = []
            question_texts = request.form.getlist('questions[][question_text]')
            question_types = request.form.getlist('questions[][question_type]')
            
            for i in range(len(question_texts)):
                if not question_texts[i].strip():
                    continue
                
                question_data = {
                    'question_text': question_texts[i].strip(),
                    'question_type': question_types[i],
                    'options': [],
                    'correct_answer': ''
                }
                
                if question_types[i] == 'mcq':
                    options = request.form.getlist(f'questions[{i}][options][]')
                    if options:
                        # Create options with letter prefixes (A, B, C, D)
                        lettered_options = [f"{chr(65+j)}. {opt.strip()}" for j, opt in enumerate(options) if opt.strip()]
                        question_data['options'] = lettered_options
                        
                        correct_answer = request.form.get(f'questions[{i}][correct_answer]')
                        if correct_answer:
                            # Store the full correct answer with letter prefix
                            correct_index = ord(correct_answer) - ord('A')
                            if 0 <= correct_index < len(lettered_options):
                                question_data['correct_answer'] = lettered_options[correct_index]
                
                questions_data.append(question_data)
            
            for question_data in questions_data:
                new_question = Question(
                    exam_id=exam_id,
                    question_text=question_data['question_text'],
                    question_type=question_data['question_type'],
                    options=question_data['options'] if question_data['options'] else None,
                    correct_answer=question_data['correct_answer']
                )
                db.session.add(new_question)
            
            db.session.commit()
            return jsonify({
                'success': True,
                'message': 'Questions added successfully',
                'redirect_url': url_for('teacher_dashboard')
            })
        except Exception as e:
            db.session.rollback()
            return jsonify({
                'success': False,
                'message': f'Error saving questions: {str(e)}'
            }), 400
    
    return render_template('add_questions.html', exam=exam, form=form)


# Exam proctoring routes
import base64
import os
import datetime
from flask_socketio import SocketIO, emit, join_room, leave_room

# Initialize SocketIO
socketio = SocketIO(app, cors_allowed_origins="*")

# Store active student webcam streams
active_streams = {}

@app.route('/exam/<int:exam_id>/proctor/save', methods=['POST'])
@login_required
@role_required('student')
def save_proctor_image(exam_id):
    """Save a proctoring image captured during an exam"""
    try:
        # Get the image data from the request
        data = request.get_json()
        if not data or 'image' not in data:
            return jsonify({'success': False, 'message': 'No image data provided'}), 400
            
        # Extract the base64 image data (remove the data URL prefix)
        image_data = data['image']
        if image_data.startswith('data:image/'):
            # Extract the base64 part after the comma
            image_data = image_data.split(',')[1]
        
        # Create directory for proctoring images if it doesn't exist
        proctoring_dir = os.path.join(app.root_path, 'static', 'proctoring')
        if not os.path.exists(proctoring_dir):
            os.makedirs(proctoring_dir)
        
        # Generate a unique filename based on user, exam, and timestamp
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"proctor_{exam_id}_{current_user.id}_{timestamp}.jpg"
        filepath = os.path.join(proctoring_dir, filename)
        
        # Save the image
        with open(filepath, 'wb') as f:
            f.write(base64.b64decode(image_data))
        
        # Broadcast the image to teachers monitoring this exam
        socketio.emit('student_webcam_update', {
            'exam_id': exam_id,
            'student_id': current_user.id,
            'student_name': current_user.username,
            'image': data['image'],
            'timestamp': timestamp
        }, room=f'exam_{exam_id}_teachers')
        
        return jsonify({
            'success': True,
            'message': 'Proctoring image saved successfully',
            'filename': filename
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error saving proctoring image: {str(e)}'
        }), 500

@app.route('/teacher/monitor/<int:exam_id>')
@login_required
@role_required('teacher')
def monitor_exam(exam_id):
    """Teacher view to monitor student webcams during an exam"""
    exam = Exam.query.get_or_404(exam_id)
    
    # Ensure the teacher owns this exam
    if exam.teacher_id != current_user.id:
        abort(403)
    
    # Get all students taking this exam
    submissions = Submission.query.filter_by(exam_id=exam_id).all()
    student_ids = [sub.student_id for sub in submissions]
    students = User.query.filter(User.id.in_(student_ids)).all() if student_ids else []
    
    return render_template('monitor_exam.html', exam=exam, students=students)

# Socket.IO event handlers
@socketio.on('connect')
def handle_connect():
    print('Client connected')

@socketio.on('join_exam_monitoring')
def handle_join_monitoring(data):
    """Teacher joins exam monitoring room"""
    exam_id = data.get('exam_id')
    if not exam_id:
        return
    
    # Verify teacher permissions here
    if current_user.role != 'teacher':
        return
    
    room = f'exam_{exam_id}_teachers'
    join_room(room)
    print(f'Teacher {current_user.id} joined monitoring room for exam {exam_id}')

@socketio.on('student_webcam_stream')
def handle_webcam_stream(data):
    """Handle student webcam stream updates"""
    if current_user.role != 'student':
        return
    
    exam_id = data.get('exam_id')
    image_data = data.get('image')
    
    if not exam_id or not image_data:
        return
    
    # Store the latest stream data
    stream_key = f'{exam_id}_{current_user.id}'
    active_streams[stream_key] = {
        'student_id': current_user.id,
        'student_name': current_user.username,
        'image': image_data,
        'timestamp': datetime.datetime.now().isoformat()
    }
    
    # Broadcast to teachers monitoring this exam
    socketio.emit('student_webcam_update', {
        'exam_id': exam_id,
        'student_id': current_user.id,
        'student_name': current_user.username,
        'image': image_data,
        'timestamp': datetime.datetime.now().isoformat()
    }, room=f'exam_{exam_id}_teachers')

# Role requirement decorator

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)