/**
 * Webcam monitoring functionality for exam proctoring
 */

class ExamProctor {
    constructor(options = {}) {
        this.options = {
            videoElement: null,
            captureInterval: 30000, // 30 seconds by default
            onCameraError: () => {},
            onCapture: () => {},
            onCameraDisabled: () => {},
            ...options
        };
        
        this.stream = null;
        this.captureTimer = null;
        this.isActive = false;
    }

    /**
     * Initialize webcam and request permissions
     */
    async initialize() {
        try {
            // Request camera access with constraints
            this.stream = await navigator.mediaDevices.getUserMedia({
                video: {
                    width: { ideal: 320 },
                    height: { ideal: 240 },
                    facingMode: "user"
                },
                audio: false
            });
            
            // Set the stream to the video element
            if (this.options.videoElement) {
                this.options.videoElement.srcObject = this.stream;
            }
            
            this.isActive = true;
            this.monitorCameraStatus();
            
            // Start periodic captures if interval is set
            if (this.options.captureInterval > 0) {
                this.startPeriodicCaptures();
            }
            
            return true;
        } catch (error) {
            console.error("Camera access error:", error);
            this.options.onCameraError(error);
            return false;
        }
    }

    /**
     * Start periodic image captures
     */
    startPeriodicCaptures() {
        if (!this.isActive) return;
        
        this.captureTimer = setInterval(() => {
            this.captureImage();
        }, this.options.captureInterval);
    }

    /**
     * Capture a single image from the webcam
     */
    captureImage() {
        if (!this.isActive || !this.options.videoElement) return null;
        
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        const video = this.options.videoElement;
        
        // Set canvas dimensions to match video
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        
        // Draw the current video frame to the canvas
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        // Convert to base64 data URL with lower quality for better performance
        // Using lower quality (0.6) to reduce data size for streaming
        const imageData = canvas.toDataURL('image/jpeg', 0.6);
        
        // Call the capture callback with the image data
        this.options.onCapture(imageData);
        
        return imageData;
    }

    /**
     * Monitor if camera is disabled during the exam
     */
    monitorCameraStatus() {
        if (!this.stream) return;
        
        // Check if any video tracks exist and are active
        const checkStatus = () => {
            const videoTracks = this.stream.getVideoTracks();
            if (videoTracks.length === 0 || !videoTracks[0].enabled || videoTracks[0].readyState !== 'live') {
                this.isActive = false;
                this.options.onCameraDisabled();
                clearInterval(this.statusTimer);
            }
        };
        
        // Check status periodically
        this.statusTimer = setInterval(checkStatus, 1000);
    }

    /**
     * Stop webcam monitoring and release resources
     */
    stop() {
        this.isActive = false;
        
        // Clear timers
        if (this.captureTimer) {
            clearInterval(this.captureTimer);
            this.captureTimer = null;
        }
        
        if (this.statusTimer) {
            clearInterval(this.statusTimer);
            this.statusTimer = null;
        }
        
        // Stop all tracks in the stream
        if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
            this.stream = null;
        }
        
        // Clear video element source
        if (this.options.videoElement) {
            this.options.videoElement.srcObject = null;
        }
    }
}